#!/usr/bin/env python
#Script Name :  Traci_Traffic_light_fixed_distance.py
#Creation Date: 29 August 2021
#Author: Shamli Soni
#Description:   This scripts changes the traffic light to green using Traci
                #if the distance between emergency vehicle and traffic light junction is less than 300m
                 

from __future__ import absolute_import
from __future__ import print_function

import os
import sys
import optparse
import random
import numpy as np


# we need to import python modules from the $SUMO_HOME/tools directory
if 'SUMO_HOME' in os.environ:
    tools = os.path.join(os.environ['SUMO_HOME'], 'tools')
    sys.path.append(tools)
else:
    sys.exit("please declare environment variable 'SUMO_HOME'")

from sumolib import checkBinary  # noqa
import traci  # noqa

vehicleID=[]
vehicleID_1=[]
vehicleID_2=[]
#ID="1_ambulance"
ID_emergency = np.array(["1_ambulance","2_ambulance","3_ambulance","4_ambulance","5_ambulance","6_ambulance","7_ambulance"])

def run():
    """execute the TraCI control loop"""
    step = 0
    while traci.simulation.getMinExpectedNumber() > 0:
        traci.simulationStep()

        for ID in ID_emergency:
            
            #Checks if the EV has entered simulation
            if ID in traci.vehicle.getIDList():
                #extracts the distance covered by the EV
               vehicleID_1=traci.vehicle.getDistance(ID)
               #distance between EV and traffic light junction at eact timestep
               Distance_cal=201.71-vehicleID_1
               Distance_cal_1=523.90-vehicleID_1
               Distance_cal_2=1171.44-vehicleID_1
               Distance_cal_4=747.65-vehicleID_1
               Distance_cal_3=982.00-vehicleID_1
               


               #conditions to check if the distance between EV and traffic light junction is less than 300 meters
               #and greater than -20 (to ensure that emergency vehicle has passed the traffic light junction
               # changes the traffic light in the direction of EV to green.
               if Distance_cal<300 and Distance_cal> -20:
                   traci.trafficlight.setPhase("cluster_1103885112_2788512876_2788512913_cluster_27598476_2788512881", 0)
                   print(Distance_cal)
                   print()

               if Distance_cal_1<300 and Distance_cal_1> -20:
                   traci.trafficlight.setPhase("joinedS_60", 0)
                   print(Distance_cal_1)
                   print()

               if Distance_cal_2<300 and Distance_cal_2> -20:
                   traci.trafficlight.setPhase("gneJ0", 4)
                   print(Distance_cal_2)
                   print()

               if Distance_cal_3<300 and Distance_cal_3> -20:
                   traci.trafficlight.setPhase("cluster_1835626514_1835626516_34070368_498562172", 0)
                   print(Distance_cal_2)
                   print()

               if Distance_cal_4<300 and Distance_cal_4> -20:
                   traci.trafficlight.setPhase("cluster_1111719993_1112233438_34013738_3587328919_3587387326", 0)
                   print(Distance_cal_2)
                   print()

                
            else:
               print("abc")
        
        
        

        step = step + 1
    traci.close()
    sys.stdout.flush()


def get_options():
    optParser = optparse.OptionParser()
    optParser.add_option("--nogui", action="store_true",
                         default=False, help="run the commandline version of sumo")
    options, args = optParser.parse_args()
    return options


# this is the main entry point of this script
if __name__ == "__main__":
    options = get_options()

    # this script has been called from the command line. It will start sumo as a
    # server, then connect and run
    if options.nogui:
        sumoBinary = checkBinary('sumo')
    else:
        sumoBinary = checkBinary('sumo-gui')

    # this is the normal way of using traci. sumo is started as a
    # subprocess and then the python script connects and runs
    traci.start([sumoBinary, "-c", "osm_fixeddistance_CL.sumocfg"])
    run()
