#!/usr/bin/env python
#Script Name :  Traci_Traffic_light.py
#Creation Date: 29 August 2021
#Author: Shamli Soni
#Description:This scripts changes the traffic light signal if the emergency
#signal approaches the traffic light junction 

from __future__ import absolute_import
from __future__ import print_function

import os
import sys
import optparse
import random
import numpy as np


# we need to import python modules from the $SUMO_HOME/tools directory
if 'SUMO_HOME' in os.environ:
    tools = os.path.join(os.environ['SUMO_HOME'], 'tools')
    sys.path.append(tools)
else:
    sys.exit("please declare environment variable 'SUMO_HOME'")

from sumolib import checkBinary  # noqa
import traci  # noqa

vehicleID=[]
vehicleID_1=[]
vehicleID_2=[]
#ID="1_ambulance"
ID_emergency = np.array(["1_ambulance","2_ambulance","3_ambulance","4_ambulance","5_ambulance","6_ambulance","7_ambulance"])

def run():
    """execute the TraCI control loop"""
    step = 0
    while traci.simulation.getMinExpectedNumber() > 0:
        traci.simulationStep()

        for ID in ID_emergency:
        
	# extracts the number of vehicle present on the lane area detectors 
            vehicle_number1 = traci.lanearea.getLastStepVehicleNumber("1")
            vehicle_number2 = traci.lanearea.getLastStepVehicleNumber("2")
            vehicle_number15 = traci.lanearea.getLastStepVehicleNumber("15")
            vehicle_number3_2 = traci.lanearea.getLastStepVehicleNumber("3")
            vehicle_number3_1 = traci.lanearea.getLastStepVehicleNumber("3_1")
            vehicle_number3 = vehicle_number3_2+vehicle_number3_1
            vehicle_number = vehicle_number1+vehicle_number2+vehicle_number15
            vehicle_number4 = traci.lanearea.getLastStepVehicleNumber("4")
            vehicle_number5 = traci.lanearea.getLastStepVehicleNumber("5")
            vehicle_number6 = traci.lanearea.getLastStepVehicleNumber("6")
            vehicle_number56 = vehicle_number5+vehicle_number6
            vehicle_number7 = traci.lanearea.getLastStepVehicleNumber("7")
            vehicle_number8 = traci.lanearea.getLastStepVehicleNumber("8")
            vehicle_number9 = traci.lanearea.getLastStepVehicleNumber("9")
            vehicle_number10 = traci.lanearea.getLastStepVehicleNumber("10")
            vehicle_number11 = traci.lanearea.getLastStepVehicleNumber("11")
            vehicle_number12 = traci.lanearea.getLastStepVehicleNumber("12")
            vehicle_number13 = traci.lanearea.getLastStepVehicleNumber("13")
            vehicle_number14 = traci.lanearea.getLastStepVehicleNumber("14")
            vehicle_number78 = vehicle_number7+vehicle_number8+vehicle_number9+vehicle_number10+vehicle_number11+vehicle_number12+vehicle_number13+vehicle_number14

        #calculates the time required to cross the Traffic light junction using the number of vehicles waiting before the traffic light junction
            Time=(vehicle_number + 1)*1.8+3
            Time_1=(vehicle_number3 + 1)*1.8+3
            Time_2=(vehicle_number4 + 1)*1.8+3
            Time_3=(vehicle_number56 + 1)*1.8+3
            Time_4=(vehicle_number78 + 1)*1.8+3
            if ID in traci.vehicle.getIDList():
                # Calulates the threshold distance for crossing the junction at each timestep
                Distance = Time*traci.vehicle.getSpeed(ID)
                Distance1 = Time_1*traci.vehicle.getSpeed(ID)
                Distance2 = Time_2*traci.vehicle.getSpeed(ID)
                Distance3 = Time_3*traci.vehicle.getSpeed(ID)
                Distance4 = Time_4*traci.vehicle.getSpeed(ID)
                print("Distance:" ,Distance)
                # extracts the distance covered by the ambulance while running in the simulation
                vehicleID_1=traci.vehicle.getDistance(ID)
                # Distance between the traffic light junction and ambulance
                Distance_cal=201.71-vehicleID_1
                Distance_cal_1=523.90-vehicleID_1
                Distance_cal_2=1171.44-vehicleID_1
                Distance_cal_4=747.65-vehicleID_1
                Distance_cal_3=982.00-vehicleID_1
                #print("Distance_cal:",Distance_cal)
                #Checks if the distance calculated of emergency vehicle is less than equal to threshold
                #distance then change the traffic light signal to green 
                if Distance_cal<=Distance and Distance_cal>0  :  
                    traci.trafficlight.setPhase("cluster_1103885112_2788512876_2788512913_cluster_27598476_2788512881", 0)
                    print("Distance_cal:",Distance_cal)

                if Distance_cal_1<=Distance1 and Distance_cal_1>0 :
                    traci.trafficlight.setPhase("joinedS_60", 0)

                if Distance_cal_2<=Distance2 and Distance_cal_2>0  :  
                    traci.trafficlight.setPhase("gneJ0", 4)
                    print("Distance_cal:",Distance_cal)

                if Distance_cal_3<=Distance3 and Distance_cal_3>0 :
                    traci.trafficlight.setPhase("cluster_1835626514_1835626516_34070368_498562172", 0)

                if Distance_cal_4<=Distance4 and Distance_cal_4>0 :
                   traci.trafficlight.setPhase("cluster_1111719993_1112233438_34013738_3587328919_3587387326", 0)

                               

        step = step + 1
    traci.close()
    sys.stdout.flush()


def get_options():
    optParser = optparse.OptionParser()
    optParser.add_option("--nogui", action="store_true",
                         default=False, help="run the commandline version of sumo")
    options, args = optParser.parse_args()
    return options


# this is the main entry point of this script
if __name__ == "__main__":
    options = get_options()

    # this script has been called from the command line. It will start sumo as a
    # server, then connect and run
    if options.nogui:
        sumoBinary = checkBinary('sumo')
    else:
        sumoBinary = checkBinary('sumo-gui')

    # this is the normal way of using traci. sumo is started as a
    # subprocess and then the python script connects and runs
    traci.start([sumoBinary, "-c", "osm_trafficlight1.sumocfg"])
    run()
